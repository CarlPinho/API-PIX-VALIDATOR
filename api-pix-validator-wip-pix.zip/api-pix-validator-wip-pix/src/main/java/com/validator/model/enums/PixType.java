package com.validator.model.enums;

import lombok.Getter;

@Getter
public enum PixType {

    EMAIL,
    CPF,
    PHONE,
    RANDOM

}
