package com.validator.model.enums;

import lombok.Getter;

@Getter
public enum TransactionStatus {

    SUCCESS,
    FAILED,
    PENDING_REVIEW

}
